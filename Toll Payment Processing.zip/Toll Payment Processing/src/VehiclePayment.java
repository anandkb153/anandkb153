import java.util.*;
class VehiclePayment {
    String vehicleNumber;
    int amountPaid;

    public VehiclePayment(String vehicleNumber, int amountPaid) {
        this.vehicleNumber = vehicleNumber;
        this.amountPaid = amountPaid;
    }
}